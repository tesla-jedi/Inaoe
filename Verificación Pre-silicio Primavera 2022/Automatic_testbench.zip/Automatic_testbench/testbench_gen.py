from pickle import FALSE, TRUE

import array as arr
import math

import re                                              #Se importa la biblioteca
######################################################Josue
man = open('design.txt')                 #Se abre el archivo
patterns=['module ','input ','output ']                #Se crean las expresiones regulares que se ocuparan
Lines= []                                              #Se crea una variable como vector
Final=''                                               #Se crea una variable como string

for linea in man:                                      #Se crea un for para poder leer el contenido en lineas
    linea = linea.rstrip()                             #Comando para leer el contenido en lineas
    for pattern in patterns:                           #Se crea un for para buscar las palabras puestas en el for en cada linea del docuemnto
        if re.search(pattern,linea):                   #Se crea un if para buscar las expresiones regulares
            linea = linea.strip()                      #Se quitan los saltos de linea que por defecto pone python
            #linea = linea.rstrip(",")                  #Se quitan las comas a al derecha
            linea = linea.replace("reg","")            #Se remplezan las variables "reg","wire"," y ";" por none
            linea = linea.replace("wire","")
            linea = linea.replace(";","")
            linea = linea.replace(")","")
            if re.search('\,',linea):                  #Se busca en cada linea hasta el final de la misma
                 linea = linea.rstrip(linea[1])
            Lines.append(linea)
            break
print(Lines)
 
Final= ''.join(Lines)                                 #Se convierte el vector en string
Final += ')'   
                                        #Se concatena el elelemnto faltante
#Final=re.sub(',','',Final,1)                           #Se elimina el elemento sobrante
print(Final)  
print(len(Lines))                                         #Se imprime
                                          #Se imprime

################################################Jose

#module="module    buses(input intp,input[5:1] entrada0,prueba,output[1:0] salida,salida4,input [3:0] entrada1,input [12:0] entrada2,prueba2,output sal,sali);//comentarios"
module=Final
var_input=[]       #entradas**
var_output=[]      #salidas**

input_list=[]       #lista de entradas sin identificador ni tamaño de buses**
output_list=[]       #lista de entradas sin identificador ni tamaño de buses**

var_list=""      #nombres de las entradas y salidas sin tomar en cuenta el tamaño del bus**
inputs=[]         #cantidad de bits por entrada**
module_name=""      #nombre del modulo**


#Comienza el programa

module_name=module[6:module.find("(")]          #Se obtiene el nombre del modulo
module_name = re.sub("\ ","",module_name)       #Se eliminan los espacios " " para dejar solo el nombre
t=module[module.find("(")+1:module.find(")")]   #se obtiene lo que esta entre "( )" recortando lo demas

isinput=FALSE
while(t!=""):
    instruction=""
    if "," in t:
        instruction=t[0:t.find(",")]        #se toma como instruccion desde posicion 0 hasta la coma
        t=t[t.find(",")+1:]         #se elimina la instruccion de el string t

    else:   #si ya no se encuentra caracter ","
        instruction=t   #se toma como instruccion todo lo que queda en t
        t=""            #se vacia string para terminar el proceso

#extraer entradas

    if re.match("input",instruction)!=None : #si instruccion comienza con palabra input
        instruction=instruction.replace("input","reg",1)    #se reemplaza input por reg
        var_input.append(instruction)  #se agrega entrada a lista de entradas

        #agregar a string de variables sin identificadores ni tamaño de buses

        if "]"  in instruction: #DETECTA SI ES UN BUS
            r1=int(instruction[instruction.find("[")+1:instruction.find(":")])  #se busca el numero a la izquierda del bus
            r2=int(instruction[instruction.find(":")+1:instruction.find("]")])  #se busca el numero a la derecha del bus
            if r1>r2:                           #se identifica el orden del bus
                inputs.append(r1-r2+1)          #se agrega a lista inputs el tamaño del bus
            elif r2>=r1:                        #se identifica el orden del bus
                inputs.append(r2-r1+1)          #se agrega a lista inputs el tamaño del bus
                                                        #se agrega cantidad de buses por entrada
            instruction=instruction[instruction.find("]")+1:] #se recorta "reg" y tamaño de buses
            
        else:                   #si no es un bus
            inputs.append(1) #se agrega 1 a lista de tamaños de entrada
            instruction=instruction[instruction.find("g")+1:] #se recorta "reg"
        var_list+=instruction+"," #se agrega a lista de variables
        instruction = re.sub("\ ","",instruction)   #se eliminan espacios en blanco " "
        input_list.append(instruction) #se agrega a lista de entradas sin identificador ni bus

        isinput=TRUE


#extraer salidas

    elif re.match("output",instruction)!=None : #si instruccion comienza con palabra output
        instruction=instruction.replace("output","wire",1)    #se reemplaza output por reg
        var_output.append(instruction)  #se agrega entrada a lista de salidas

        #agregar a string de variables sin identificadores ni tamaño de buses

        if "]"  in instruction: #DETECTA SI ES UN BUS
            instruction=instruction[instruction.find("]")+1:] #se recorta "wire" y tamaño de buses
        else:
            instruction=instruction[instruction.find("e")+1:] #se recorta "wire"
        var_list+=instruction+","   #se agrega a lista de variables
        instruction = re.sub("\ ","",instruction)   #se eliminan espacios en blanco " "
        output_list.append(instruction) #se agrega a lista de entradas sin identificador ni bus
        
        
        isinput=FALSE


#extraer entradas o salidas sin identificador

    elif isinput==TRUE:         #si la primer palabra no especifica si es input o output se analiza si el ultimo elemento fue input o output
        temp=var_input[-1]      #si fue input se toma el ultimo elemento de la lista de entradas
        if "]" in temp:         #si se encuentra caracter "]" significa que es un bus
            temp=temp[0:temp.find("]")+1]       #copia "reg" del input y su tamaño de bus
            #tamaño del bus
            r1=int(temp[temp.find("[")+1:temp.find(":")])  #se busca el numero a la izquierda del bus
            r2=int(temp[temp.find(":")+1:temp.find("]")])  #se busca el numero a la derecha del bus
            if r1>r2:                           #se identifica el orden del bus
                inputs.append(r1-r2+1)          #se agrega a lista inputs el tamaño del bus
            elif r2>=r1:                        #se identifica el orden del bus
                inputs.append(r2-r1+1)          #se agrega a lista inputs el tamaño del bus
                                                        #se agrega cantidad de buses por entrada
        else:                   #si no es un bus
            inputs.append(1) #se agrega 1 a lista de tamaños de entrada
            temp="reg"      #solo copia el "reg"
        temp=temp+" "+instruction               #concatena "reg" + " " + el nombre de la instruccion
        var_input.append(temp)                  #se agrega a lista de entradas

        #agregar a string de variables sin identificadores ni tamaño de buses
        var_list+=instruction+","
        instruction = re.sub("\ ","",instruction)   #se eliminan espacios en blanco " "
        input_list.append(instruction) #se agrega a lista de entradas sin identificador ni bus
        
    elif isinput==FALSE:        #si ultima variable fue salida

        temp=var_output[-1]     #si fue output se toma el ultimo elemento de la lista de salidas
        if "]" in temp:         #si se encuentra caracter "]" significa que es un bus
            temp=temp[0:temp.find("]")+1]       #copia "wire" del output y su tamaño de bus
        else:                   #si no es un bus
            temp="wire"      #solo copia el "wire"
        temp=temp+" "+instruction               #concatena "wire" + " " + el nombre de la instruccion
        var_output.append(temp)                 #se agrega a lista de salidas
        #agregar a string de variables sin identificadores ni tamaño de buses
        var_list+=instruction+","
        instruction = re.sub("\ ","",instruction)   #se eliminan espacios en blanco " "
        output_list.append(instruction) #se agrega a lista de salidas sin identificador ni bus

if "," in var_list:
    var_list=var_list[:-1]  #se elimina la ultima ","
var_list = re.sub("\ ","",var_list)       #Se eliminan los espacios " "

print("LISTAS")
print("ENTRADAS: ")
print(var_input)
print("SALIDAS: ")
print(var_output)
print("LISTA DE VARIABLES: ")
print(var_list)
print("INPUT_LIST: ")
print(input_list)
print("OUTPUT_LIST: ")
print(output_list)
print("INPUTS: ")
print(inputs)
print("MODULO")
print(module_name)
###############################Bruno

#bits=arr.array('i',[1,2,1,1])

lista=input_list
outputs=output_list


TotalInputs=len(input_list)
TotalOutputs=len(output_list)
accum=0
for w in inputs:
    accum=accum+w
    
pot = (2**accum)
limpot=(pot/2)
limpotint=int(limpot)

limpotm=limpotint-10
limpotM=limpotint+10
pot_s=str(pot)
limpot_s=str(limpot)
limpotm_s=str(limpotm)
limpotM_s=str(limpotM)
potm=pot-10
potm_s=str(potm)


lines = ['`timescale 1ns/100ps', 'module mux_TB ();']

for i in range(len(var_input)):
    lines.append(var_input[i]+';')

for i in range(len(var_output)):
    lines.append(var_output[i]+';')


module_name=module_name+" DUT"+'('+var_list+')'
lines.append(module_name+';')
lines.append('initial begin')
lines.append('  $dumpvars;')
lines.append('  $dumpfile("dump.vcd");')
##/////////////////////////////////////////////
print (pot)
if pot<=64:


    for i in range (0,TotalInputs):   
        lines.append(lista[i]+'<=0;')

    monitor=('$monitor("')
    monitor+='in: '
    for i in range (0,len(input_list)):
        monitor+='%b '
    monitor+='out: '
    for i in range (0,len(output_list)):
        monitor+='%b '
    monitor+='" '

    for i in range (0,TotalInputs):
        monitor+=','
        monitor+=lista[i]
    for i in range (0,TotalOutputs):
        monitor+=','
        monitor+=outputs[i] 
    monitor+=');'
    lines.append(monitor)
    lines.append('for (int i=0;i<'+pot_s+';i=i+1) begin')
    s = ','.join(lista)
    lines.append('   {'+s+'}=i;')    
    lines.append('   #10;')
    lines.append('end')


elif pot>64:
    for i in range (0,TotalInputs):   
        lines.append(lista[i]+'<=0;')

    monitor=('$monitor("')
    monitor+='in: '
    for i in range (0,len(input_list)):
        monitor+='%b '
    monitor+='out: '
    for i in range (0,len(output_list)):
        monitor+='%b '
    monitor+='" '

    for i in range (0,TotalInputs):
        monitor+=','
        monitor+=lista[i]
    for i in range (0,TotalOutputs):
        monitor+=','
        monitor+=outputs[i] 
    monitor+=');'
    lines.append(monitor)

    lines.append('for (int i=0;i<10;i=i+1) begin')
    s = ','.join(lista)
    lines.append('   {'+s+'}=i;')
    lines.append('   #10;')
    lines.append('end')

    lines.append('for (int i='+limpotm_s+';i<'+limpotM_s+';i=i+1) begin')
    s = ','.join(lista)
    lines.append('   {'+s+'}=i;')
    lines.append('   #10;')
    lines.append('end')

    lines.append('for (int i='+potm_s+';i<'+pot_s+';i=i+1) begin')
    s = ','.join(lista)
    lines.append('   {'+s+'}=i;')
    lines.append('   #10;')
    lines.append('end')

##/////////////////////////////////////////////
lines.append('  $finish;')
lines.append('end')

#\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
lines.append('endmodule')

with open('TestBench_python.txt', 'w') as f:
    f.write('\n'.join(lines))